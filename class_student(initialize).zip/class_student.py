class Student:
  def __init__(self, name, answers_given):
    self.name = name
    self.answers_given = answers_given